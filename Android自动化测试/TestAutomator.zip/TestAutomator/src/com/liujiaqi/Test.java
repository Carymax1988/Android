package com.liujiaqi;

import com.android.uiautomator.core.UiDevice;
import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;
/**
 * android create uitest-project -n demo -t 19 -p D:\AndroidStudy\TestAutomator
 * adb push D:\AndroidStudy\TestAutomator\bin\demo.jar /data/local/tmp
 * adb shell uiautomator runtest demo.jar -c com.liujiaqi.Test
 * @author liujiaqi
 *
 */
public class Test extends UiAutomatorTestCase{
	public void testDemo() throws UiObjectNotFoundException{
		UiDevice.getInstance().pressHome();
		UiObject browserObject = new UiObject(new UiSelector().text("浏览器"));
		browserObject.clickAndWaitForNewWindow();
		UiObject editObject = new UiObject(new UiSelector().className("android.widget.EditText"));
		editObject.click();
		UiDevice.getInstance().pressDelete();
		editObject.setText("www.baidu.com");
		UiDevice.getInstance().pressEnter();
		sleep(2000);
	}
}
