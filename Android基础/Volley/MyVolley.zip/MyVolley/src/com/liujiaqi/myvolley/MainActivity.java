package com.liujiaqi.myvolley;

import org.json.JSONArray;

import com.android.volley.RequestQueue;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.ImageLoader.ImageCache;
import com.android.volley.toolbox.ImageLoader.ImageListener;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.Volley;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.LruCache;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;

public class MainActivity extends Activity {

	ImageView imageView1 = null;
	NetworkImageView imageView2 = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		imageView1 = (ImageView) findViewById(R.id.imageView1);
		imageView2 = (NetworkImageView) findViewById(R.id.imageView2);
		getJsonVolley();
		loadImageVolley();
		NetWorkImageViewVolley();
	}
	
	//��ȡJson�ַ���
	public void getJsonVolley(){
		RequestQueue requestQueue = Volley.newRequestQueue(this);
		String JSONDateUrl = "http://aqicn.org/publishingdata/json/";
		JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(JSONDateUrl,
				new Listener<JSONArray>() {

					@Override
					public void onResponse(JSONArray response) {
						System.out.println("response = "+response);
					}
				},
				new ErrorListener() {
					@Override
					public void onErrorResponse(VolleyError errorresponse) {
						System.out.println("errorresponse = "+errorresponse);
					}
				});
		requestQueue.add(jsonArrayRequest);
	}

	//��ȡͼƬ http://www.baidu.com/img/bd_logo1.png
	public void loadImageVolley(){
		String imageurl = "http://www.baidu.com/img/bd_logo1.png";
		RequestQueue requestQueue = Volley.newRequestQueue(this);
		final LruCache<String, Bitmap> lurcache = new LruCache<String, Bitmap>(20);
		ImageCache imageCache = new ImageCache() {
			
			@Override
			public void putBitmap(String key, Bitmap value) {
				lurcache.put(key, value);
			}
			
			@Override
			public Bitmap getBitmap(String key) {
				return lurcache.get(key);
			}
		};
		ImageLoader imageLoader = new ImageLoader(requestQueue, imageCache);
		ImageListener listener = imageLoader.getImageListener(imageView1, R.drawable.ic_launcher, R.drawable.ic_launcher);
		imageLoader.get(imageurl, listener);
	}
	
	public void NetWorkImageViewVolley(){
		String  imageurl = "http://www.baidu.com/img/bd_logo1.png";
		RequestQueue requestQueue = Volley.newRequestQueue(this);
		final LruCache<String, Bitmap> lurcache = new LruCache<String, Bitmap>(20);
		ImageCache imageCache = new ImageCache() {
			
			@Override
			public void putBitmap(String key, Bitmap value) {
				lurcache.put(key, value);
			}
			
			@Override
			public Bitmap getBitmap(String key) {
				return lurcache.get(key);
			}
		};
		ImageLoader imageLoader = new ImageLoader(requestQueue, imageCache);
		imageView2.setTag("url");
		imageView2.setImageUrl(imageurl, imageLoader);
	}
}
