/** Automatically generated file. DO NOT MODIFY */
package com.liujiaqi.myvolley;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}